import React from "react";
import FullDapp from "./FullDapp";

function App() {
  return <FullDapp />;
}

export default App;